#!/bin/bash
echo "Enter linux command to perform:" 
read linuxCommand
echo "Command to be executed: $linuxCommand" 
$linuxCommand 
