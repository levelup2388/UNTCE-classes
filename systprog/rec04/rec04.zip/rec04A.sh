#!/bin/bash	
if [ $# -eq 1 ]; then 
echo "Good day, $1! Nice to meet you!"
else
echo "Hope you have a great day!"
fi
