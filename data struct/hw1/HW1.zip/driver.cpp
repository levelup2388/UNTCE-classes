#include "hello.h"

int main(){
	
	hello myHello;
	myHello.sayHello();
	
	return 0;
	
}