//header file with the prototype for:  
#include <iostream>
#include <string>
using namespace std;


 
class hello
{
	public:
		void sayHello();
};
// OK to make it a struct