//Implementation of:   the "hello" class  void sayHello()
    
#include "hello.h"  // & any others you need

	void hello::sayHello()
	{
		cout<<"Hello world!\n";
		
		return;
	}