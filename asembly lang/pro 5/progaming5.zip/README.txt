READ-ME

X21-original starting adress of a
X22-original starting adress of b
X23-original starting adress of c(storage vector)
X1-load address for 4 parts of a incremented
X2-load address for 4 parts of b incremented
X0- increment value
X12-loop counter
Q0-where 4 values of a are loaded into
Q1-where 4 values of b are loaded into
Q2- storage vector
V0.4S- Q0 as 4 parts
V1.4S- Q1 as 4 parts
V2.4S- q2 as 4 parts
S11- temp sorage register
V2.2S- takes 2 partial additions and adds those together
