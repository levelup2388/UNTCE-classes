Code compiled using the unt csce putty machince
with the gcc compiler, and running with ./aout
test input
Fibonacci.c- no input
vector.c- no input
senctence.c- "this Is  A test"
cos.c- x=4, a=3